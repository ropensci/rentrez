#' Set global variables 
#'
#' 
#'@export

entrez_email <- "david.winter@gmail.com"
entrez_tool <- "rentrez"

