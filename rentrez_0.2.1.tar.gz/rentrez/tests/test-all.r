library(testthat)
library(rentrez)

test_package("rentrez")
